

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8"><br>
                <div class="card">
                    <div class="card-header d-flex flex-row"><h4>Editar Paciente</h4><div class="d-flex flex-row-reverse w-50"><a href="<?php echo e(route('pacientes.index')); ?>" class="btn btn-secondary">Voltar</a></div></div>
                    

                    <div class="card-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form method="post" action="<?php echo e(route('pacientes.update', $paciente->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <label for="nome">Nome:</label>
                                <input type="text" class="form-control" name="nome" value="<?php echo e($paciente->nome); ?>" />
                            </div>
                            <div class="form-group">
                                <label for="cpf">CPF:</label>
                                <input type="text" class="form-control" name="cpf" value="<?php echo e($paciente->cpf); ?>" />
                            </div>
                            <div class="form-group">
                                <label for="email">E-mail:</label>
                                <input type="text" class="form-control" name="email" value="<?php echo e($paciente->email); ?>" />
                            </div>
                            <div class="form-group">
                                <label for="profissional_id">Profissional:</label>
                                <select class="form-control" name="profissional_id">
                                    <?php $__currentLoopData = $profissionais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profissional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($profissional->id); ?>" <?php echo e($profissional->id == $paciente->profissional_id ? 'selected' : ''); ?>><?php echo e($profissional->nome); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="password">Senha:</label>
                                <input type="text" class="form-control" name="password" />
                            </div>
                            <br>
                            <button type="submit" class="btn btn-primary">Salvar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.painel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatec5semestre\evolutec\resources\views/pacientes/edit.blade.php ENDPATH**/ ?>