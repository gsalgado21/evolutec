

<?php $__env->startSection('content'); ?>
<br><div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h3 class="mb-0">Profissionais</h3>
                <a href="<?php echo e(route('profissionais.create')); ?>" class="btn btn-success mb-3">Novo Profissional</a>
            </div>

            <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            
            <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>CRM</th>
                            <th>Nome</th>
                            <th>Especialidade</th>
                            <th>Tipo</th>
                            <th>Atualizado em</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $profissionais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profissional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($profissional->id); ?></td>
                            <td><?php echo e($profissional->crm); ?></td>
                            <td><?php echo e($profissional->nome); ?></td>
                            <td><?php echo e($profissional->especialidade); ?></td>
                            <td><?php echo e($profissional->tipo); ?></td>
                            <td><?php echo e($profissional->updated_at->format('d/m/Y H:i')); ?></td>
                            <td>
                                <form action="<?php echo e(route('profissionais.destroy', $profissional->id)); ?>" method="POST">
                                    <a href="<?php echo e(route('profissionais.show', $profissional->id)); ?>" class="btn btn-sm btn-primary mr-1">Ver</a>
                                    <a href="<?php echo e(route('profissionais.edit', $profissional->id)); ?>" class="btn btn-sm btn-warning mr-1">Editar</a>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja excluir o profissional <?php echo e($profissional->nome); ?>?')">Excluir</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.painel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatec5semestre\evolutec\resources\views/profissionais/index.blade.php ENDPATH**/ ?>