

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12"><br>
            <h3 class="mb-3">Novo AVD</h3>

            <form action="<?php echo e(route('avds.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <input type="text" class="form-control" name="descricao" id="descricao" required>
                </div>

                <div class="form-group">
                    <br>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                    <a href="<?php echo e(route('avds.index')); ?>" class="btn btn-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.painel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatec5semestre\evolutec\resources\views/avds/create.blade.php ENDPATH**/ ?>