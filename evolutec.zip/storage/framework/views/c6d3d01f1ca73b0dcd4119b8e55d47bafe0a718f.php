

<?php $__env->startSection('content'); ?>
<br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3 class="mb-0">Lista de Pacientes</h3>
                    <a href="<?php echo e(route('pacientes.create')); ?>" class="btn btn-success mb-3">Novo Paciente</a>
                </div>

                <div class="table-responsive">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <form action="<?php echo e(route('pacientes.index')); ?>" method="GET" class="form-inline mb-3">
                        <div class="form-group mr-2 d-flex flex-row">
                            <input type="text" name="q" class="form-control" placeholder="Pesquisar por nome...">
                            <button type="submit" class="btn btn-primary">Filtrar</button>
                        </div>
                        
                    </form>
                    <br>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>CPF</th>
                                <th>Profissional</th>
                                <th>Criado em</th>
                                <th>Atualizado em</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($paciente->id); ?></td>
                                    <td><?php echo e($paciente->nome); ?></td>
                                    <td><?php echo e($paciente->cpf); ?></td>
                                        <td><?php echo e($paciente->profissional->nome); ?></td>
                                        <td><?php echo e($paciente->created_at); ?></td>
                                        <td><?php echo e($paciente->updated_at); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('pacientes.show', $paciente->id)); ?>" class="btn btn-sm btn-primary mr-1">Ver</a>
                                            <a href="<?php echo e(route('pacientes.edit', $paciente->id)); ?>" class="btn btn-sm btn-warning mr-1">Editar</a>
                                            <form action="<?php echo e(route('pacientes.destroy', $paciente->id)); ?>" method="post" class="d-inline-block">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir esse paciente?')">Excluir</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($pacientes->appends(['q' => request()->input('q')])->links()); ?>

                    </div>
                </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
        
<?php echo $__env->make('layout.painel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatec5semestre\evolutec\resources\views/pacientes/index.blade.php ENDPATH**/ ?>