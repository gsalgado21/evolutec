

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12"><br>
            <h3 class="mb-3">Detalhes do AVD</h3>

            <div class="card">
                <div class="card-body">
                    <h3 class="card-title"><?php echo e($avd->descricao); ?></h3>

                    <div class="row">
                        <div class="col-md-6">
                            <p class="card-text"><strong>ID:</strong> <?php echo e($avd->id); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p class="card-text"><strong>Criado em:</strong> <?php echo e($avd->created_at->format('d/m/Y H:i:s')); ?></p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <p class="card-text"><strong>Última atualização:</strong> <?php echo e($avd->updated_at->format('d/m/Y H:i:s')); ?></p>
                        </div>
                    </div>

                    <div class="row">
                        
                        <div class="col-md-12"><br>
                            <a href="<?php echo e(route('avds.edit', $avd->id)); ?>" class="btn btn-primary">Editar</a>
                            <a href="<?php echo e(route('avds.index')); ?>" class="btn btn-secondary">Voltar</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.painel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatec5semestre\evolutec\resources\views/avds/show.blade.php ENDPATH**/ ?>