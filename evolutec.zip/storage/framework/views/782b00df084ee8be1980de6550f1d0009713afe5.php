

<?php $__env->startSection('content'); ?>
<br>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h3 class="mb-0">Lista de AVDs</h3>
                <a href="<?php echo e(route('avds.create')); ?>" class="btn btn-success mb-3"   >Novo AVD</a>
            </div>

            <div class="table-responsive">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Descrição</th>
                            <th>Criado em</th>
                            <th>Atualizado em</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $avds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($avd->id); ?></td>
                                <td><?php echo e($avd->descricao); ?></td>
                                <td><?php echo e($avd->created_at->format('d/m/Y H:i:s')); ?></td>
                                <td><?php echo e($avd->updated_at->format('d/m/Y H:i:s')); ?></td>
                                <td>
                                    <a href="<?php echo e(route('avds.show', $avd->id)); ?>" class="btn btn-sm btn-primary">Ver</a>
                                    <a href="<?php echo e(route('avds.edit', $avd->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
                                    <form action="<?php echo e(route('avds.destroy', $avd->id)); ?>" method="POST" style="display: inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Deseja realmente excluir este AVD?')">Excluir</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.painel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatec5semestre\evolutec\resources\views/avds/index.blade.php ENDPATH**/ ?>