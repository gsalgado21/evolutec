<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\fatec5semestre\evolutec\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>