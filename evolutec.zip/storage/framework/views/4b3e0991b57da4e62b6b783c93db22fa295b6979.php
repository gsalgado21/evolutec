

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12"><br>
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h3 class="mb-0">Detalhes do Profissional</h3>
                <a href="<?php echo e(route('profissionais.index')); ?>" class="btn btn-secondary">Voltar</a>
            </div>

            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($profissional->nome); ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($profissional->especialidade); ?></h6>
                    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($profissional->tipo); ?></h6>
                    <p class="card-text">CRM: <?php echo e($profissional->crm); ?></p>
                    <p class="card-text">E-mail: <?php echo e($profissional->email); ?></p>
                    <p class="card-text">Criado em: <?php echo e($profissional->created_at->format('d/m/Y H:i:s')); ?></p>
                    <p class="card-text">Última atualização em: <?php echo e($profissional->updated_at->format('d/m/Y H:i:s')); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.painel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatec5semestre\evolutec\resources\views/profissionais/show.blade.php ENDPATH**/ ?>